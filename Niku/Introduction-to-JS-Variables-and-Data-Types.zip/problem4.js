// Store the name, school, grade, section, rollno and the marks scored by the student in 3 subjects
// Print the report card of the student (You can make it look nice by using some keyboard symbols )

let name;
let school;
let grade;
let section;
let rollno;
let phy;
let chem;
let maths;

name="Name : Cunnu";
school=" School : Masai-School";
grade="Grade : A+";
section="Section : a";
rollno="Roll no. : 101";
phy="Physics : 79/100";
chem="Chemistry : 89/100";
maths="Maths : 99/100";

console.log(name,school,grade,section,rollno,phy,chem,maths);


name="Name : Munnu";
school=" School : Masai-School";
grade="Grade : A+";
section="Section : a";
rollno="Roll no. : 102";
phy="Physics : 70/100";
chem="Chemistry : 82/100";
maths="Maths : 97/100";

console.log(name,school,grade,section,rollno,phy,chem,maths);


name="Name : Tunnu";
school=" School : Masai-School";
grade="Grade : A+";
section="Section : a";
rollno="Roll no. : 103";
phy="Physics : 85/100";
chem="Chemistry : 97/100";
maths="Maths : 98/100";

console.log(name,school,grade,section,rollno,phy,chem,maths);
