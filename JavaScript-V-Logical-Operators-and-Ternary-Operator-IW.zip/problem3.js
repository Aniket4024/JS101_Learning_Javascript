// Problem 3 : Given and character if it is a consonant print "Consonant"

let char="d";

if (char!=="a" || char!=="e" || char!=="i" || char!=="o" || char!=="u"){
  console.log("Consonant");
}