// Problem 5: Given the days of the week in short format "Sun", "Mon" ... print in long format "Sunday", "Monday", ...

let day="Swt";

if (day==="Sun"){
  console.log("Sunday");
}
else if (day==="Mon"){
  console.log("Monday");
}
else if (day==="Tue"){
  console.log("Tuesday");
}
else if (day==="Wed"){
  console.log("Wednesday");
}
else if (day==="Thu"){
  console.log("Thursday");
}
else if (day==="Fri"){
  console.log("Friday");
}
else if (day==="Sat"){
  console.log("Saturday");
}
