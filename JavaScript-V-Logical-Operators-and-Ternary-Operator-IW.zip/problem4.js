// Problem 4: Given 3 numbers (all different values), print which is greatest

let a=15;
let b=10;
let c=52;


if (a>b && a>c){
  console.log(a,"is greater than",b,"and",c);
}
else if (b>a && b>c){
  console.log(b,"is greater than",a,"and",c);
}
else {
  console.log(c,"is greater than",a,"and",b);
}